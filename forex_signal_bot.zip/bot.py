
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import requests
import pandas as pd
import ta
from datetime import datetime, timedelta

TELEGRAM_TOKEN = "7579324377:AAGWd4DndfZKwyM2QmHrMi8PRNe7OtyxZ78"
CHAT_ID = 8107192044
API_KEY = "Y0G51JV9HJ5H8B12"

logging.basicConfig(level=logging.INFO)

def get_forex_data(symbol: str):
    url = f"https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol={symbol[:3]}&to_symbol={symbol[3:]}&interval=1min&apikey={API_KEY}&outputsize=compact"
    response = requests.get(url)
    data = response.json()
    try:
        df = pd.DataFrame(data['Time Series FX (1min)']).T.astype(float)
        df.sort_index(inplace=True)
        return df
    except Exception as e:
        logging.error(f"Error fetching data for {symbol}: {e}")
        return None

def analyze_signal(df: pd.DataFrame):
    df['rsi'] = ta.momentum.RSIIndicator(df['4. close']).rsi()
    latest_rsi = df['rsi'].iloc[-1]
    if latest_rsi < 30:
        return "CALL (3 min)"
    elif latest_rsi > 70:
        return "PUT (3 min)"
    return None

TOP_PAIRS = ["EURUSD", "USDJPY", "GBPUSD", "AUDUSD", "USDCAD",
             "USDCHF", "NZDUSD", "EURJPY", "GBPJPY", "EURGBP",
             "AUDJPY", "CHFJPY", "EURCAD", "CADJPY", "NZDJPY"]

def scan_forex_pairs():
    signals = []
    for pair in TOP_PAIRS:
        df = get_forex_data(pair)
        if df is not None:
            signal = analyze_signal(df)
            if signal:
                signals.append(f"{pair}: {signal}")
    return signals

async def send_signals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔍 Scanning top Forex pairs for 3-minute signals...")
    signals = scan_forex_pairs()
    if signals:
        for signal in signals:
            await context.bot.send_message(chat_id=CHAT_ID, text=f"📈 Signal: {signal}")
    else:
        await context.bot.send_message(chat_id=CHAT_ID, text="⚠️ No high-probability signals at the moment.")

# Start the bot
app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
app.add_handler(CommandHandler("scan", send_signals))

print("✅ Bot is running...")
app.run_polling()
