# Forex Signal Bot

This Telegram bot scans the top 15 Forex pairs using RSI and provides high-probability 3-minute binary trade signals.

## Features
- Real-time data from Alpha Vantage
- RSI-based signal analysis
- Telegram bot notifications
- 3-minute CALL/PUT signals

## Deployment (Railway)

1. Push this repo to GitHub.
2. Go to https://railway.app, create a new project.
3. Deploy from GitHub.
4. Add the following environment variables:
   - TELEGRAM_TOKEN
   - API_KEY
   - CHAT_ID
5. Railway auto-installs from requirements.txt.

Command to start the bot:  
```
worker: python bot.py
```
